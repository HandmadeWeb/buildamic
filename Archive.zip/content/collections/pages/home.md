---
id: home
title: Home
template: home
author: 331b0000-8020-4496-a4eb-6a6379248540
updated_by: 331b0000-8020-4496-a4eb-6a6379248540
updated_at: 1621413099
buildamic:
  -
    type: section
    rows:
      -
        type: row
        columns:
          -
            type: column
            fields:
              -
                type: set
                value:
                  title: 'Title Test'
                  description: Testing
                  type: blurb
replicator:
  -
    title: 'Blurb title'
    description: 'Blurb description'
    type: blurb
    enabled: true
markdown: 'Markdown description'
---
Welcome to your new Statamic website.