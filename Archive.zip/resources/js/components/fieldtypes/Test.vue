<template>

    <div>
        <text-input :value="value" @input="update" />
    </div>

</template>

<script>
/**
 * Register this component with:
 * Vue.component('test-fieldtype', require('./path/to/Test.vue'))
 */
export default {

    mixins: [Fieldtype],

    data() {
        return {
            //
        };
    }

};
</script>
